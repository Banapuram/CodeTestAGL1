﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace AGL.Pets.Tests
{
    [TestClass]
    public class AGLPetsUnitTest
    {
        [TestMethod()]
        public void testAGLCats()
        {
            //Arrange
            List<Person> per = new List<Person>();
            Person objp = new Person();
            objp.name = "John";
            objp.gender = "M";
            objp.petName = "Puppy";
            objp.petType = "Dog";

            per.Add(objp);

            objp.name = "Joe";
            objp.gender = "F";
            objp.petName = "Pou";
            objp.petType = "Cat";

            per.Add(objp);

            objp.name = "Joe1";
            objp.gender = "M";
            objp.petName = "Pou1";
            objp.petType = "Cat";

            per.Add(objp);

            //Act
            //List<Person> items = JsonConvert.DeserializeObject<List<Person>>(json);
            //var filtered = items.Where(x => x.pets != null && x.gender == "Male" && x.pets.Where(y => y.type == "Cat").Count() > 0);
            //return JsonConvert.SerializeObject(filtered);

            

            //Asser
            Assert.IsTrue(false);

        }

    }

    public class Person
    {
        public string name;
        public string gender;
        public string petName;
        public string petType;
    }

    
}
