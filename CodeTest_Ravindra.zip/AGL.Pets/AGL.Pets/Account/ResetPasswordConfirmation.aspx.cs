﻿using System.Web.UI;

namespace AGL.Pets.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}