﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AGL.Pets
{
    public partial class PetsHome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        [WebMethod]
        public static string getPeople()
        {
            try
            {
                StreamReader r = new StreamReader(HttpContext.Current.Server.MapPath("Scripts/people.json"));
                string json = r.ReadToEnd();

                List<Person> items = JsonConvert.DeserializeObject<List<Person>>(json);

                return JsonConvert.SerializeObject(items);
            }
            catch
            {
                return null;
                //Logging exception using MSEnterprise Library orLog4Net
            }
        }

        [WebMethod]
        public static string getMaleWithCat()
        {
            try
            {
                StreamReader r = new StreamReader(HttpContext.Current.Server.MapPath("Scripts/people.json"));
                string json = r.ReadToEnd();

                List<Person> items = JsonConvert.DeserializeObject<List<Person>>(json);
                var filtered = items.Where(x => x.pets != null && x.gender == "Male" && x.pets.Where(y => y.type == "Cat").Count() > 0);


                return JsonConvert.SerializeObject(filtered);
            }
            catch
            {
                return null;
                //Logging exception using MSEnterprise Library orLog4Net
            }
        }

        [WebMethod]
        public static string getFemaleWithCat()
        {
            try
            {

                StreamReader r = new StreamReader(HttpContext.Current.Server.MapPath("Scripts/people.json"));
                string json = r.ReadToEnd();

                List<Person> items = JsonConvert.DeserializeObject<List<Person>>(json);
                var filtered = items.Where(x => x.pets != null && x.gender == "Female" && x.pets.Where(y => y.type == "Cat").Count() > 0);

                return JsonConvert.SerializeObject(filtered);
            }
            catch
            {
                return null;
                //Logging exception using MSEnterprise Library orLog4Net
            }
        }

    }

    public class Person
    {
        public string name;
        public string gender;
        public int age;
        public List<Pet> pets;
    }

    public class Pet
    {
        public string name;
        public string type;
    }
}