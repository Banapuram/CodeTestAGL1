﻿var dataSet;

$(document).ready(function () {

    $.ajax({
        type: "POST",
        url: "PetsHome.aspx/getMaleWithCat",
        data: '{}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            //debugger;
            //dataFromJsonSource
            var htmlTblString = "<table class='table table-condensed table-bordered table-hover'><thead><th colspan='2' class='col-lg-6'>Male</th></thead><tbody>";
            dataSet = JSON.parse(data.d);
            for (var i = 0; i < dataSet.length; i++) {
                for (var j = 0; j < dataSet[i].pets.length; j++) {
                    if (dataSet[i].pets[j].type == "Cat") {
                        htmlTblString += "<tr><td>";
                        htmlTblString += "<div class='col-lg-12'>" + dataSet[i].pets[j].name + "</div>";
                        htmlTblString += "</td></tr>";
                    }
                }
            }
            htmlTblString += "</table>";
            $("#filteredDataMale").html(htmlTblString);
        },
        failure: function (response) {
            alert(response.d);
        }
    });
    $.ajax({
        type: "POST",
        url: "PetsHome.aspx/getFemaleWithCat",
        data: '{}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            //debugger;
            //dataFromJsonSource
            var htmlTblString = "<table class='table table-condensed table-bordered table-hover'><thead><th colspan='2' class='col-lg-6'>Female</th></thead><tbody>";
            dataSet = JSON.parse(data.d);
            for (var i = 0; i < dataSet.length; i++) {
                for (var j = 0; j < dataSet[i].pets.length; j++) {
                    if (dataSet[i].pets[j].type == "Cat") {
                        htmlTblString += "<tr><td>";
                        htmlTblString += "<div class='col-lg-12'>" + dataSet[i].pets[j].name + "</div>";
                        htmlTblString += "</td></tr>";
                    }
                }
            }
            htmlTblString += "</table>";
            $("#filteredDataFemale").html(htmlTblString);
        },
        failure: function (response) {
            alert(response.d);
        }
    });

    //return;

    //debugger;
    $.ajax({
        type: "POST",
        url: "PetsHome.aspx/getPeople",
        data: '{}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            //debugger;
            //dataFromJsonSource
            var htmlTblString = "<table class='table table-condensed table-bordered table-hover'><thead><th  class='col-lg-6'>Person</th><th  class='col-lg-6'>Pets</th></thead><tbody>";
            dataSet = JSON.parse(data.d);
            for (var i = 0; i < dataSet.length; i++) {
                htmlTblString += "<tr><td>";
                htmlTblString += "<div class='col-lg-12'><strong>Name: </strong>" + dataSet[i].name + "</div>";
                htmlTblString += "<div class='col-lg-12'><strong>" + dataSet[i].gender + "</strong>, <em>" + dataSet[i].age + "</em></div></td><td>";
                if (dataSet[i].pets != null) {
                    for (var j = 0; j < dataSet[i].pets.length; j++) {
                        htmlTblString += "<div class='col-lg-12'><strong>#" + (j + 1) + ": " + dataSet[i].pets[j].name + " </strong> (<em>" + dataSet[i].pets[j].type + "</em>)</div>";
                    }
                }
                htmlTblString += "</td></tr>";
            }
            htmlTblString += "</table>";
            $("#dataFromJsonSource").html(htmlTblString);
        },
        failure: function (response) {
            alert(response.d);
        }
    });
});

function getPersonsWithDogs() {
    //debugger;
    $.ajax({
        type: "POST",
        url: "PetsHome.aspx/getPeopleWithDog",
        data: '{}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            //debugger;
            //dataFromJsonSource
            var htmlTblString = "<table class='table table-condensed table-bordered table-hover'><thead><th  class='col-lg-6'>Person</th><th  class='col-lg-6'>Pets</th></thead><tbody>";
            dataSet = JSON.parse(data.d);
            for (var i = 0; i < dataSet.length; i++) {
                htmlTblString += "<tr><td>";
                htmlTblString += "<div class='col-lg-12'><strong>Name: </strong>" + dataSet[i].name + "</div>";
                htmlTblString += "<div class='col-lg-12'><strong>" + dataSet[i].gender + "</strong>, <em>" + dataSet[i].age + "</em></div></td><td>";
                if (dataSet[i].pets != null) {
                    for (var j = 0; j < dataSet[i].pets.length; j++) {
                        htmlTblString += "<div class='col-lg-12'><strong>#" + (j + 1) + ": " + dataSet[i].pets[j].name + " </strong> (<em>" + dataSet[i].pets[j].type + "</em>)</div>";
                    }
                }
                htmlTblString += "</td></tr>";
            }
            htmlTblString += "</table>";
            $("#filteredData").html(htmlTblString);
        },
        failure: function (response) {
            alert(response.d);
        }
    });
}
function getPersonsWithCats() {
    debugger;
    $.ajax({
        type: "POST",
        url: "PetsHome.aspx/getMaleWithCat",
        data: '{}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            //debugger;
            //dataFromJsonSource
            var htmlTblString = "<table class='table table-condensed table-bordered table-hover'><thead><th colspan='2' class='col-lg-6'>Male</th></thead><tbody>";
            dataSet = JSON.parse(data.d);
            for (var i = 0; i < dataSet.length; i++) {
                for (var j = 0; j < dataSet[i].pets.length; j++) {
                    if (dataSet[i].pets[j].type == "Cat") {
                        htmlTblString += "<tr><td>";
                        htmlTblString += "<div class='col-lg-12'>" + dataSet[i].pets[j].name + "</div>";
                        htmlTblString += "</td></tr>";
                    }
                }
            }
            htmlTblString += "</table>";
            $("#filteredData").html(htmlTblString);
        },
        failure: function (response) {
            alert(response.d);
        }
    });
}
function getPersonsWithFish() {
    //debugger;
    $.ajax({
        type: "POST",
        url: "PetsHome.aspx/getPeopleWithFish",
        data: '{}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (data) {
            //debugger;
            //dataFromJsonSource
            var htmlTblString = "<table class='table table-condensed table-bordered table-hover'><thead><th  class='col-lg-6'>Person</th><th  class='col-lg-6'>Pets</th></thead><tbody>";
            dataSet = JSON.parse(data.d);
            for (var i = 0; i < dataSet.length; i++) {
                htmlTblString += "<tr><td>";
                htmlTblString += "<div class='col-lg-12'><strong>Name: </strong>" + dataSet[i].name + "</div>";
                htmlTblString += "<div class='col-lg-12'><strong>" + dataSet[i].gender + "</strong>, <em>" + dataSet[i].age + "</em></div></td><td>";
                if (dataSet[i].pets != null) {
                    for (var j = 0; j < dataSet[i].pets.length; j++) {
                        htmlTblString += "<div class='col-lg-12'><strong>#" + (j + 1) + ": " + dataSet[i].pets[j].name + " </strong> (<em>" + dataSet[i].pets[j].type + "</em>)</div>";
                    }
                }
                htmlTblString += "</td></tr>";
            }
            htmlTblString += "</table>";
            $("#filteredData").html(htmlTblString);
        },
        failure: function (response) {
            alert(response.d);
        }
    });
}